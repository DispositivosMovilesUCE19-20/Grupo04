const express = require('express');
const bodyParser = require('body-parser')
const app = express();
const port = process.env.PORT || 9998
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())
var resp = "";
const fs = require('fs')
const js2xml = require("js2xmlparser")

app.get('/operacion/:id', function(req, res, next) {
if (req.params.id == "editar") {
  resp = "El Estudiante se ha editado correctamente.";
}else if (req.params.id == "eliminar") {
  resp = "El Estudiante se ha eliminado correctamente.";
}else {
  resp = "Se produjo un problema en la Edici�n/Eliminaci�n";
}
  res.json({msg: resp});
});

//Metodo para enviar un mensaje al cliente Android
app.get('/mensajeExamen', (req, res) =>{
  res.send({ msg: 'EXAMEN OPTATIVA III'})
})

//Guardar formato json
app.put('/upload',function(req,res){
  var json = req.body
  console.log(json)
fs.writeFile('jsonExamen/usuarios.json',json,(error)=>{	
  if(error){
    throw error;
  }
      console.log('Archivo Creado');
      res.send(200)
      res.end()
})

})

app.get('/G4T7', (req, res) => {
res.send({ msg: 'SERVICIO GRUPO 04'}) 
})





app.listen(port, () => {
 console.log(`El servidor est� inicializado en el puerto ${port}`);
});

module.exports = app;